class Node {
    constructor(data) {
        this.data = data;
        this.next =null;
    }
}

class SLL {
    constructor() {
        this.head = null;
    }
    addFront(val) {
        let new_node = new Node(val);
        
        if(!this.head) {
            this.head = new_node;
            return this;
        }
        new_node.next = this.head;
        this.head = new_node;
        return this;
    }
    removeFront() {
        if(!this.head) {
            return this;
        }
        this.head = this.head.next
    }

    front() {
        return this.head.data;
    }

    contains(val) {
        let runner = this.head
        let exists = false

        while(runner !== null) {
            if(val == runner.data) {
                exists = true
                break
            }
        }

        return exists
    }
}

SLL1 = new SLL()

SLL1.addFront(18)
SLL1.addFront(73)

console.log(SLL1)

SLL1.removeFront()

console.log(SLL1)

x = SLL1.front()

console.log(x)